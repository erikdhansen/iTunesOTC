class Playlist:
	def __init__(self,playListName=None):
		self.name = playListName
		self.tracks = []
